A Pen created at CodePen.io. You can find this one at https://codepen.io/chrisgannon/pen/yXmbMg.

 Everybody loves LEGO and nobody likes waiting. 

I've lost track of the number of vehicles and buildings I've made with my son since he had his tonsils out. I just had to dip back into the digital realm for a few hours!